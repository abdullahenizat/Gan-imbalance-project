
# Exploring GAN Variants for Balancing Imbalanced Datasets

## Special Topics in Artificial Intelligence

Instructor: Dr. Yousef Sanjalawe  
Course: Special Topics in AI, Section 1, Spring 2024/2025  
Student: Abdullah Mohammed Jamil AL-Enizat (2220599)

---

### Objective
This project explores the use of Generative Adversarial Networks (GANs) to handle the challenge of class imbalance using the Fashion-MNIST dataset. The project compares the performance of Vanilla GAN and WGAN.

---

### Dataset
- Fashion-MNIST dataset containing 10 classes.
- Selected minority class: Sandal (label 5).
- Class imbalance visualized and addressed.

---

### GAN Architectures
- **Vanilla GAN**: Basic GAN model for generating synthetic images.
- **WGAN**: Improved model with Wasserstein loss and weight constraints to enhance training stability and output quality.

---

### Classifier Evaluation
- CNN classifier trained under three scenarios:
  1. Original imbalanced dataset.
  2. Dataset balanced with Vanilla GAN-generated data.
  3. Dataset balanced with WGAN-generated data.
- Evaluated using metrics: Accuracy, Precision, Recall, F1-Score, AUC-ROC.

---

### Results
- Visualization of generated samples from both GAN models.
- Comparative performance analysis of classifiers.
- Metrics presented with confusion matrices and ROC curves.

---

### How to Run
1. Clone the repository.
2. Install dependencies with `pip install -r requirements.txt`.
3. Run the notebook using `jupyter notebook GAN_FashionMNIST.ipynb`.

---

### Deliverables
- Source code in Jupyter Notebook format.
- Report (PDF) with methodology, analysis, and results.
- Recorded video presentation (3–5 minutes).

---

### Acknowledgements
Project submitted for the Special Topics in AI course under the supervision of Dr. Yousef Sanjalawe, KASIT, JU.
